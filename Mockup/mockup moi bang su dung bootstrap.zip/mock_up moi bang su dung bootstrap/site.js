//scroll Back To Top
$(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 200) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('html,body').animate({scrollTop: 0}, 1000);
        });
});

//so luong & tinh gia
function increaseValue(id) {
	var sl = "sl" + id.toString();
  var value = parseInt(document.getElementById(sl).value, 10);
  value = isNaN(value) ? 0 : value;
  value++;
	document.getElementById(sl).value = value;
	tinhTongTien(id);
}

function decreaseValue(id) {
	var sl = "sl" + id.toString();
  var value = parseInt(document.getElementById(sl).value, 10);
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
	if(value > 1)
		value--;
  document.getElementById(sl).value = value;
	tinhTongTien(id);
}

function tinhTongTien(id) {
  var sl = parseInt(document.getElementById('sl'+id).value, 10);
	var dg = document.getElementById('dg'+id).innerHTML;
	var dg = dg.replace(".", "");
	var dg = parseInt(dg, 10);
	var tt = sl * dg;
	document.getElementById('tt'+id).innerHTML = tt;
}


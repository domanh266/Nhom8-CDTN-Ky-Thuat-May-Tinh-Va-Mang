<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HangSanXuat extends Model
{
    protected $table = 'hang_san_xuat';
    public $timestamps = false;
}
